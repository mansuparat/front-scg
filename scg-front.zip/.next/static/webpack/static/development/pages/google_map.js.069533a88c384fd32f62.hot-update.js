webpackHotUpdate("static\\development\\pages\\google_map.js",{

/***/ "./containers/GoogleMap.js":
/*!*********************************!*\
  !*** ./containers/GoogleMap.js ***!
  \*********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/Layout */ "./components/Layout.js");
/* harmony import */ var _components_GoogleMap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/GoogleMap */ "./components/GoogleMap.js");
var _jsxFileName = "C:\\Users\\COMMERZY-PC\\Documents\\scg-front\\containers\\GoogleMap.js";




class GoogleMap extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {
  constructor() {
    super();
    this.state = {
      key_google_api: 'AIzaSyDJVbkePROCadDMjDFMH_f1P_a5O4FXbiE',
      center: {
        lat: 13.8279156,
        lng: 100.5286286
      },
      zoom: 16,
      locations: []
    };
  }

  async componentDidMount() {
    await this.Get_Data_Google_Map();
  }

  async Get_Data_Google_Map() {
    let newState = this.state;
    var result = [];
    var result_center = [];
    await fetch('http://127.0.0.1:3333/google_map', {
      method: 'get',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      }
    }).then(res => {
      if (res.status !== 200) throw new Error(res.status);else return res.json();
    }).then(res => {
      for (var i = 0; i < res.length; i++) {
        if (i == 0) {
          result_center.push({
            lat: res[i]['geometry']['location']['lat'],
            lng: res[i]['geometry']['location']['lng']
          });
        }

        result.push({
          id: i,
          lat: res[i]['geometry']['location']['lat'],
          lng: res[i]['geometry']['location']['lng'],
          show: false
        });
      }

      newState.center = result_center[0];
      newState.locations = result;
    }).catch(error => {
      console.log('error: ' + error);
    });
    this.setState(newState);
  }

  _onChildMouseEnter(event) {
    console.log(event);
  }

  render() {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 63
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_Layout__WEBPACK_IMPORTED_MODULE_1__["default"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 64
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_GoogleMap__WEBPACK_IMPORTED_MODULE_2__["default"], {
      state: this.state,
      _onChildMouseEnter: event => this._onChildMouseEnter(event),
      __source: {
        fileName: _jsxFileName,
        lineNumber: 65
      },
      __self: this
    })));
  }

}

/* harmony default export */ __webpack_exports__["default"] = (GoogleMap);

/***/ })

})
//# sourceMappingURL=google_map.js.069533a88c384fd32f62.hot-update.js.map
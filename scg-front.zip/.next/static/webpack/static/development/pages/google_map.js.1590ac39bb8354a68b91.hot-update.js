webpackHotUpdate("static\\development\\pages\\google_map.js",{

/***/ "./components/my_great_place_with_hover.js":
/*!*************************************************!*\
  !*** ./components/my_great_place_with_hover.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return MyGreatPlaceWithHover; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _my_great_place_with_hover_styles_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./my_great_place_with_hover_styles.js */ "./components/my_great_place_with_hover_styles.js");
/* harmony import */ var _InfoWindow__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./InfoWindow */ "./components/InfoWindow.js");
var _jsxFileName = "C:\\Users\\COMMERZY-PC\\Documents\\scg-front\\components\\my_great_place_with_hover.js";



class MyGreatPlaceWithHover extends react__WEBPACK_IMPORTED_MODULE_0___default.a.PureComponent {
  render() {
    const style = this.props.$hover ? _my_great_place_with_hover_styles_js__WEBPACK_IMPORTED_MODULE_1__["greatPlaceStyleHover"] : _my_great_place_with_hover_styles_js__WEBPACK_IMPORTED_MODULE_1__["greatPlaceStyle"];
    const infoWindowStyle = {
      position: 'relative',
      bottom: 150,
      left: '-45px',
      width: 220,
      backgroundColor: 'white',
      boxShadow: '0 2px 7px 1px rgba(0, 0, 0, 0.3)',
      padding: 10,
      fontSize: 14,
      zIndex: 100
    };
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      style: style,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 23
      },
      __self: this
    }, this.props.text, props.show && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_InfoWindow__WEBPACK_IMPORTED_MODULE_2__["default"], {
      place: props.place,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 25
      },
      __self: this
    }));
  }

}

/***/ })

})
//# sourceMappingURL=google_map.js.1590ac39bb8354a68b91.hot-update.js.map
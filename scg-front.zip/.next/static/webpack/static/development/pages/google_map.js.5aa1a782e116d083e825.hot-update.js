webpackHotUpdate("static\\development\\pages\\google_map.js",{

/***/ "./components/my_great_place_with_hover.js":
/*!*************************************************!*\
  !*** ./components/my_great_place_with_hover.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return MyGreatPlaceWithHover; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _my_great_place_with_hover_styles_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./my_great_place_with_hover_styles.js */ "./components/my_great_place_with_hover_styles.js");
var _jsxFileName = "C:\\Users\\COMMERZY-PC\\Documents\\scg-front\\components\\my_great_place_with_hover.js";


class MyGreatPlaceWithHover extends react__WEBPACK_IMPORTED_MODULE_0___default.a.PureComponent {
  render() {
    const style = this.props.$hover ? _my_great_place_with_hover_styles_js__WEBPACK_IMPORTED_MODULE_1__["greatPlaceStyleHover"] : _my_great_place_with_hover_styles_js__WEBPACK_IMPORTED_MODULE_1__["greatPlaceStyle"];
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      style: style,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 11
      },
      __self: this
    }, "dasdsadsadsadas", this.props.text);
  }

}

/***/ })

})
//# sourceMappingURL=google_map.js.5aa1a782e116d083e825.hot-update.js.map
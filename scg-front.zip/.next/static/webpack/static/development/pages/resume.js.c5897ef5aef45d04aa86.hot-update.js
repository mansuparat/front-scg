webpackHotUpdate("static\\development\\pages\\resume.js",[
/* 0 */
/*!*********************************************************************************************************************************************!*\
  !*** multi next-client-pages-loader?page=%2Fresume&absolutePagePath=C%3A%5CUsers%5CCOMMERZY-PC%5CDocuments%5Cscg-front%5Cpages%5Cresume.js ***!
  \*********************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! next-client-pages-loader?page=%2Fresume&absolutePagePath=C%3A%5CUsers%5CCOMMERZY-PC%5CDocuments%5Cscg-front%5Cpages%5Cresume.js! */"./node_modules/next/dist/build/webpack/loaders/next-client-pages-loader.js?page=%2Fresume&absolutePagePath=C%3A%5CUsers%5CCOMMERZY-PC%5CDocuments%5Cscg-front%5Cpages%5Cresume.js!./");


/***/ }),
/* 1 */
false
])
//# sourceMappingURL=resume.js.c5897ef5aef45d04aa86.hot-update.js.map
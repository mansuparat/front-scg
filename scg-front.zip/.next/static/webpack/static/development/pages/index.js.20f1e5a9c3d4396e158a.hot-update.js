webpackHotUpdate("static\\development\\pages\\index.js",{

/***/ "./containers/Index.js":
/*!*****************************!*\
  !*** ./containers/Index.js ***!
  \*****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_core_js_parse_int__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/parse-int */ "./node_modules/@babel/runtime-corejs2/core-js/parse-int.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_parse_int__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_parse_int__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/Layout */ "./components/Layout.js");
/* harmony import */ var _components_Index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/Index */ "./components/Index.js");

var _jsxFileName = "C:\\Users\\COMMERZY-PC\\Documents\\scg-front\\containers\\Index.js";




class index extends react__WEBPACK_IMPORTED_MODULE_1___default.a.Component {
  constructor() {
    super();
    this.state = {
      array_seq: ["3", "5", "9", "15", "X", "Y", "Z"],
      seq_x: "?",
      seq_y: "?",
      seq_z: "?"
    };
  }

  async componentDidMount() {}

  async find_sequence() {
    let newState = this.state;
    var array_sequence = newState.array_seq;
    var tmp_array = 0;
    var result = 0;

    for (var i = 0; i < array_sequence.length; i++) {
      if (isNaN(_babel_runtime_corejs2_core_js_parse_int__WEBPACK_IMPORTED_MODULE_0___default()(array_sequence[i]))) {
        result = tmp_array + 2 * i;
        tmp_array = result;
        array_sequence[i] = result;
      } else {
        tmp_array = _babel_runtime_corejs2_core_js_parse_int__WEBPACK_IMPORTED_MODULE_0___default()(array_sequence[i]);
        array_sequence[i] = _babel_runtime_corejs2_core_js_parse_int__WEBPACK_IMPORTED_MODULE_0___default()(array_sequence[i]);
      }
    }

    newState.seq_x = array_sequence[4];
    newState.seq_y = array_sequence[5];
    newState.seq_z = array_sequence[6];
    newState.array_seq = array_sequence;
    this.setState(newState);
  }

  render() {
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 47
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_components_Layout__WEBPACK_IMPORTED_MODULE_2__["default"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 48
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_components_Index__WEBPACK_IMPORTED_MODULE_3__["default"], {
      state: this.state,
      find_sequence: () => this.find_sequence(),
      __source: {
        fileName: _jsxFileName,
        lineNumber: 49
      },
      __self: this
    })));
  }

}

/* harmony default export */ __webpack_exports__["default"] = (index);

/***/ })

})
//# sourceMappingURL=index.js.20f1e5a9c3d4396e158a.hot-update.js.map
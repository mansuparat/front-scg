webpackHotUpdate("static\\development\\pages\\google_map.js",{

/***/ "./components/GoogleMap.js":
/*!*********************************!*\
  !*** ./components/GoogleMap.js ***!
  \*********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "./node_modules/styled-jsx/style.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var google_map_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! google-map-react */ "./node_modules/google-map-react/lib/index.js");
/* harmony import */ var google_map_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(google_map_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _my_great_place_with_hover__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./my_great_place_with_hover */ "./components/my_great_place_with_hover.js");
/* harmony import */ var _my_great_place_with_hover_styles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./my_great_place_with_hover_styles */ "./components/my_great_place_with_hover_styles.js");
var _jsxFileName = "C:\\Users\\COMMERZY-PC\\Documents\\scg-front\\components\\GoogleMap.js";






const GoogleMap = props => react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
  class: "container-fluid",
  __source: {
    fileName: _jsxFileName,
    lineNumber: 6
  },
  __self: undefined
}, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
  class: "d-sm-flex align-items-center justify-content-between mb-4",
  __source: {
    fileName: _jsxFileName,
    lineNumber: 8
  },
  __self: undefined
}, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
  style: {
    height: '100vh',
    width: '100%'
  },
  className: "jsx-3923483773",
  __source: {
    fileName: _jsxFileName,
    lineNumber: 9
  },
  __self: undefined
}, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(google_map_react__WEBPACK_IMPORTED_MODULE_2___default.a, {
  onChildClick: event => props.onChildClick(event),
  bootstrapURLKeys: {
    key: props.state.key_google_api
  },
  defaultCenter: props.state.center,
  defaultZoom: props.state.zoom,
  hoverDistance: _my_great_place_with_hover_styles__WEBPACK_IMPORTED_MODULE_4__["K_SIZE"] / 2,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 10
  },
  __self: undefined
}, props.state.locations.map((data, index) => react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_my_great_place_with_hover__WEBPACK_IMPORTED_MODULE_3__["default"], {
  text: data.id + 1,
  lat: data.lat,
  lng: data.lng,
  show: data.show,
  place: data.place,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 18
  },
  __self: undefined
}))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
  id: "3923483773",
  __self: undefined
}, "body{margin:0;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcQ09NTUVSWlktUENcXERvY3VtZW50c1xcc2NnLWZyb250XFxjb21wb25lbnRzXFxHb29nbGVNYXAuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBeUJ1QixBQUdnQixTQUNWIiwiZmlsZSI6IkM6XFxVc2Vyc1xcQ09NTUVSWlktUENcXERvY3VtZW50c1xcc2NnLWZyb250XFxjb21wb25lbnRzXFxHb29nbGVNYXAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgR29vZ2xlTWFwUmVhY3QgZnJvbSAnZ29vZ2xlLW1hcC1yZWFjdCc7XHJcbmltcG9ydCBNeUdyZWF0UGxhY2VXaXRoSG92ZXIgZnJvbSAnLi9teV9ncmVhdF9wbGFjZV93aXRoX2hvdmVyJztcclxuaW1wb3J0IHsgS19TSVpFIH0gZnJvbSAnLi9teV9ncmVhdF9wbGFjZV93aXRoX2hvdmVyX3N0eWxlcyc7XHJcblxyXG5jb25zdCBHb29nbGVNYXAgPSAocHJvcHMpID0+IChcclxuICAgIDxkaXYgY2xhc3M9XCJjb250YWluZXItZmx1aWRcIj5cclxuICBcclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImQtc20tZmxleCBhbGlnbi1pdGVtcy1jZW50ZXIganVzdGlmeS1jb250ZW50LWJldHdlZW4gbWItNFwiPlxyXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGhlaWdodDogJzEwMHZoJywgd2lkdGg6ICcxMDAlJyB9fT5cclxuICAgICAgICA8R29vZ2xlTWFwUmVhY3RcclxuICAgICAgICAgIG9uQ2hpbGRDbGljaz17KGV2ZW50KSA9PiBwcm9wcy5vbkNoaWxkQ2xpY2soZXZlbnQpfVxyXG4gICAgICAgICAgYm9vdHN0cmFwVVJMS2V5cz17eyBrZXk6IHByb3BzLnN0YXRlLmtleV9nb29nbGVfYXBpIH19XHJcbiAgICAgICAgICBkZWZhdWx0Q2VudGVyPXtwcm9wcy5zdGF0ZS5jZW50ZXJ9XHJcbiAgICAgICAgICBkZWZhdWx0Wm9vbT17cHJvcHMuc3RhdGUuem9vbX1cclxuICAgICAgICAgIGhvdmVyRGlzdGFuY2U9e0tfU0laRSAvIDJ9XHJcbiAgICAgICAgPlxyXG5cdFx0XHRcdHtwcm9wcy5zdGF0ZS5sb2NhdGlvbnMubWFwKChkYXRhLCBpbmRleCkgPT4gKFxyXG4gICAgICA8TXlHcmVhdFBsYWNlV2l0aEhvdmVyXHJcbiAgICAgICAgdGV4dD17ZGF0YS5pZCArIDF9XHJcbiAgICAgICAgbGF0PXtkYXRhLmxhdH1cclxuICAgICAgICBsbmc9e2RhdGEubG5nfVxyXG4gICAgICAgIHNob3c9e2RhdGEuc2hvd31cclxuICAgICAgICBwbGFjZT17ZGF0YS5wbGFjZX1cclxuICAgICAgICAgICAgICAgIC8+KSl9XHJcbiAgICAgICAgPC9Hb29nbGVNYXBSZWFjdD5cclxuXHRcdFx0XHQ8c3R5bGUganN4IGdsb2JhbD57YFxyXG5cdFx0XHRcdFx0Ym9keSB7IFxyXG5cdFx0XHRcdFx0XHRtYXJnaW46IDA7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0YH08L3N0eWxlPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgXHJcbiAgXHJcbiAgICAgICAgICA8L2Rpdj5cclxuICApXHJcbiAgXHJcbiAgZXhwb3J0IGRlZmF1bHQgR29vZ2xlTWFwIl19 */\n/*@ sourceURL=C:\\Users\\COMMERZY-PC\\Documents\\scg-front\\components\\GoogleMap.js */"))));

/* harmony default export */ __webpack_exports__["default"] = (GoogleMap);

/***/ })

})
//# sourceMappingURL=google_map.js.3de65564266eea65180d.hot-update.js.map
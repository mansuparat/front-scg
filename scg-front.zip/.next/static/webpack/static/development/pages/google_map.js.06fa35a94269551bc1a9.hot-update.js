webpackHotUpdate("static\\development\\pages\\google_map.js",{

/***/ "./components/my_great_place_with_hover.js":
/*!*************************************************!*\
  !*** ./components/my_great_place_with_hover.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return MyGreatPlaceWithHover; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _my_great_place_with_hover_styles_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./my_great_place_with_hover_styles.js */ "./components/my_great_place_with_hover_styles.js");
var _jsxFileName = "C:\\Users\\COMMERZY-PC\\Documents\\scg-front\\components\\my_great_place_with_hover.js";


class MyGreatPlaceWithHover extends react__WEBPACK_IMPORTED_MODULE_0___default.a.PureComponent {
  render() {
    const style = this.props.$hover ? _my_great_place_with_hover_styles_js__WEBPACK_IMPORTED_MODULE_1__["greatPlaceStyleHover"] : _my_great_place_with_hover_styles_js__WEBPACK_IMPORTED_MODULE_1__["greatPlaceStyle"];
    const infoWindowStyle = {
      position: 'relative',
      bottom: 150,
      left: '-45px',
      width: 220,
      backgroundColor: 'white',
      boxShadow: '0 2px 7px 1px rgba(0, 0, 0, 0.3)',
      padding: 10,
      fontSize: 14,
      zIndex: 100
    };
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 21
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      style: style,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 22
      },
      __self: this
    }, this.props.text), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      style: infoWindowStyle,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 25
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      style: {
        fontSize: 16
      },
      __source: {
        fileName: _jsxFileName,
        lineNumber: 26
      },
      __self: this
    }, "a"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      style: {
        fontSize: 14
      },
      __source: {
        fileName: _jsxFileName,
        lineNumber: 29
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
      style: {
        color: 'grey'
      },
      __source: {
        fileName: _jsxFileName,
        lineNumber: 30
      },
      __self: this
    }, "a"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
      style: {
        color: 'orange'
      },
      __source: {
        fileName: _jsxFileName,
        lineNumber: 33
      },
      __self: this
    }, "a"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
      style: {
        color: 'lightgrey'
      },
      __source: {
        fileName: _jsxFileName,
        lineNumber: 36
      },
      __self: this
    }, "a")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      style: {
        fontSize: 14,
        color: 'grey'
      },
      __source: {
        fileName: _jsxFileName,
        lineNumber: 40
      },
      __self: this
    }, "a"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      style: {
        fontSize: 14,
        color: 'grey'
      },
      __source: {
        fileName: _jsxFileName,
        lineNumber: 43
      },
      __self: this
    }, "a"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      style: {
        fontSize: 14,
        color: 'green'
      },
      __source: {
        fileName: _jsxFileName,
        lineNumber: 46
      },
      __self: this
    }, "a")));
  }

}

/***/ })

})
//# sourceMappingURL=google_map.js.06fa35a94269551bc1a9.hot-update.js.map
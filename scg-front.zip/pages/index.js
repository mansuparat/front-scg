import IndexContainer from '../containers/Index'

const Index = () => (
  <IndexContainer>

  </IndexContainer>
)

export default Index
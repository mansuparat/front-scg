import ResumeContainer from '../containers/Resume'

const Resume = () => (
  <ResumeContainer>

  </ResumeContainer>
)

export default Resume
import GoogleMapContainer from '../containers/GoogleMap'

const Google_map = () => (
  <GoogleMapContainer>

  </GoogleMapContainer>
)

export default Google_map